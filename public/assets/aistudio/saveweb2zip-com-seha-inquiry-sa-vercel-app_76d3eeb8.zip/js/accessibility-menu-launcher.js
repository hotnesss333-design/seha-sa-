(() => {
  const host = document.getElementById('accessibility-menu-host');
  if (!host || host.dataset.bound === 'true') return;
  const button = host.querySelector('#userwayAccessibilityIcon');
  const frame = host.querySelector('iframe[name="userway"]');
  if (!button || !frame) return;
  host.dataset.bound = 'true';

  let pressAnimationTimer;
  let frameReady = false;

  const accessSettings = {};
  [
    's2', 's3', 's4', 's6', 's7', 's8', 's9', 's10', 's11', 's12',
    's13', 's14', 's15', 's16', 's17', 's18', 's19', 's21', 's23',
    's24', 's25', 's101', 's102', 's103', 's104', 's105', 's106',
    's107', 's108'
  ].forEach((name) => {
    accessSettings[`userway-${name}`] = { disabled: false, value: null };
  });

  const widgetConfig = {
    account: '2w89zcJOTG',
    origin: window.location.origin,
    href: window.location.href,
    onPrem: true,
    widgetLayout: 'full',
    language: 'ar',
    widgetPageLang: 'ar',
    uid: null,
    reader: { enabled: true },
    // Source page state: paid_widget layout with the original three-column menu.
    services: { paidAi: true },
    settings: accessSettings,
    tunings: {
      site_name: 'seha.sa',
      widget_color: '#306db5',
      widget_color_gradient: '',
      widget_icon_size: 'large',
      widget_icon_type: '1',
      widget_language: 'ar',
      widget_page_lang: 'ar',
      widget_position: '5',
      widget_no_report: true,
      widget_no_logo: false,
      widget_no_manage: false,
      widget_dictionary: true,
      widget_sounds: false,
      widget_live_language_enabled: true,
      widget_lst_button_enabled: false,
      widget_header_button: true,
      widget_custom_line_height_lvls_count: 3,
      widget_custom_text_spacing_lvls_count: 3,
      accessibility_link_enabled: 'on',
      new_manage: true,
      isLAUser: false
    },
    _userway_config: {
      color: '#306db5',
      gradient: ''
    }
  };

  const postToFrame = (data) => {
    if (!frame.contentWindow) return;
    frame.contentWindow.postMessage({ isUserWay: true, ...data }, '*');
  };

  const sendConfig = () => {
    postToFrame({ action: 'sendConfig', data: { config: widgetConfig } });
  };

  const syncFrameState = () => {
    sendConfig();
    postToFrame({ action: 'toggled', state: host.classList.contains('uon') ? 'show' : 'hide', trigger: 'main' });
  };

  const scheduleFrameSync = () => {
    [0, 200, 600, 1500, 3000].forEach((delay) => {
      window.setTimeout(syncFrameState, delay);
    });
  };

  const playPressAnimation = () => {
    window.clearTimeout(pressAnimationTimer);
    button.classList.add('userway_loading');
    pressAnimationTimer = window.setTimeout(() => {
      button.classList.remove('userway_loading');
    }, 760);
  };

  const setFrameVisibility = (open) => {
    // UserWay's original stylesheet leaves .uwif at opacity: 0!important.
    // Set the final state inline so the original iframe can be seen when opened.
    frame.style.setProperty('display', open ? 'block' : 'none', 'important');
    frame.style.setProperty('visibility', 'visible', 'important');
    frame.style.setProperty('opacity', open ? '1' : '0', 'important');
  };

  const setOpen = (open, focus = false) => {
    host.classList.toggle('uon', open);
    button.setAttribute('aria-expanded', String(open));
    setFrameVisibility(open);
    if (open) {
      frame.removeAttribute('aria-hidden');
      postToFrame({ action: 'toggled', state: 'show', trigger: 'main' });
    } else {
      frame.setAttribute('aria-hidden', 'true');
      postToFrame({ action: 'toggled', state: 'hide', trigger: 'main' });
    }
    if (focus && !open) button.focus();
  };

  const toggleOpen = () => {
    playPressAnimation();
    setOpen(!host.classList.contains('uon'));
  };

  const bindOriginalClose = () => {
    const frameDoc = frame.contentDocument;
    if (!frameDoc || frameDoc.documentElement.dataset.accessCloseBound === 'true') return;
    frameDoc.documentElement.dataset.accessCloseBound = 'true';
    const bind = () => {
      const close = frameDoc.querySelector('button[aria-label="أغلق قائمة الوصول"], button[aria-label="Close the accessibility menu"]');
      if (close && close.dataset.parentCloseBound !== 'true') {
        close.dataset.parentCloseBound = 'true';
        close.addEventListener('click', () => setOpen(false, true), true);
      }
    };
    bind();
    new MutationObserver(bind).observe(frameDoc.body || frameDoc.documentElement, { subtree: true, childList: true });
  };

  const onFrameMessage = (event) => {
    if (event.source !== frame.contentWindow) return;
    const data = event.data || {};
    if (data.action === 'getConfig') {
      sendConfig();
      return;
    }
    if (data.action === 'isWidgetOpened') {
      postToFrame({ action: 'toggled', state: host.classList.contains('uon') ? 'show' : 'hide', trigger: 'main' });
      return;
    }
    if (data.action === 'close' || data.type === 'close' || data.event === 'close') {
      setOpen(false, true);
    }
  };

  setOpen(false);
  button.addEventListener('click', toggleOpen);
  button.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      toggleOpen();
    }
  });
  frame.addEventListener('load', () => {
    frameReady = true;
    bindOriginalClose();
    scheduleFrameSync();
  });
  window.addEventListener('message', onFrameMessage);
  bindOriginalClose();
  scheduleFrameSync();
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && host.classList.contains('uon')) setOpen(false, true);
  });
})();
