(() => {
  'use strict';

  const loaded = new Set();

  function loadScript(src, attributes = {}) {
    if (!src || loaded.has(src)) return Promise.resolve();
    loaded.add(src);
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      Object.entries(attributes).forEach(([name, value]) => script.setAttribute(name, value));
      script.addEventListener('load', resolve, { once: true });
      script.addEventListener('error', reject, { once: true });
      document.head.appendChild(script);
    });
  }

  function loadUserWayFrame() {
    const frame = document.querySelector('#accessibility-menu-host iframe[name="userway"]');
    if (!frame || frame.dataset.performanceLoaded === 'true') return;
    const source = frame.getAttribute('data-lazy-src');
    if (!source) return;
    frame.dataset.performanceLoaded = 'true';
    frame.setAttribute('src', source);
  }

  function loadRecaptcha() {
    const base = './صحة - منصة الخدمات الصحية_files/';
    return loadScript(`${base}recaptcha__ar.js.download`, { type: 'text/javascript' })
      .then(() => loadScript(`${base}api.js.download`, { id: 'google-recaptcha-v3', type: 'text/javascript' }))
      .catch(() => undefined);
  }

  function loadDeferredServices() {
    loadUserWayFrame();
    loadScript('./صحة - منصة الخدمات الصحية_files/convai-widget-embed@beta', { type: 'text/javascript' }).catch(() => undefined);
    loadRecaptcha();
  }

  function schedule() {
    const run = () => window.setTimeout(loadDeferredServices, 900);
    if (typeof window.requestIdleCallback === 'function') {
      window.requestIdleCallback(run, { timeout: 2500 });
    } else {
      window.setTimeout(run, 1200);
    }
  }

  const accessButton = document.querySelector('#userwayAccessibilityIcon');
  if (accessButton) {
    accessButton.addEventListener('pointerdown', loadUserWayFrame, { passive: true });
    accessButton.addEventListener('keydown', loadUserWayFrame, { passive: true });
  }

  if (document.readyState === 'complete') schedule();
  else window.addEventListener('load', schedule, { once: true });
})();
