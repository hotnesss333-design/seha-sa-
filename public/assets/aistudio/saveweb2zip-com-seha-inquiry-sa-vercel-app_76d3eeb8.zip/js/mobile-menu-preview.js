(() => {
  'use strict';

  function installMobileMenuBridge() {
    const button = document.querySelector('.menu-img.navbar-toggler');
    const menu = document.getElementById('responsive-navbar-nav');
    if (!button || !menu || button.dataset.mobileMenuBridge === 'installed') return;

    button.dataset.mobileMenuBridge = 'installed';

    const setMenuState = (open) => {
      button.classList.toggle('collapsed', !open);
      button.setAttribute('aria-expanded', String(open));
      menu.classList.add('collapse');
      menu.classList.toggle('show', open);
    };

    setMenuState(menu.classList.contains('show'));

    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      setMenuState(!menu.classList.contains('show'));
    }, true);

    menu.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => setMenuState(false), true);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', installMobileMenuBridge, { once: true });
  } else {
    installMobileMenuBridge();
  }
})();
