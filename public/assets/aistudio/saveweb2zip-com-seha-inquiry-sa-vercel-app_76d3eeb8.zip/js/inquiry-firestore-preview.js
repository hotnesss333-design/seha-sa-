(function () {
  'use strict';

  const COLLECTION_URL = 'https://firestore.googleapis.com/v1/projects/authentication-c9e71/databases/(default)/documents/publicInquiries';
  const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
  const LATIN_DIGITS = '0123456789';
  let attached = false;

  function normalizeDigits(value) {
    return String(value || '')
      .replace(/[٠-٩]/g, (digit) => LATIN_DIGITS[ARABIC_DIGITS.indexOf(digit)])
      .replace(/\D/g, '');
  }

  function findInput(label) {
    return [...document.querySelectorAll('input')].find((input) =>
      String(input.getAttribute('aria-label') || '').includes(label) ||
      String(input.placeholder || '').includes(label)
    );
  }

  function findControls() {
    const serviceInput = findInput('رمز الخدمة');
    const identityInput = findInput('رقم الهوية');
    const button = [...document.querySelectorAll('button')].find((candidate) => {
      const text = String(candidate.textContent || '').replace(/\s+/g, ' ').trim();
      return text === 'استعلام' || text === 'استعلام جديد' || candidate.id === 'searchButton';
    });
    if (!serviceInput || !identityInput || !button) return null;
    return { serviceInput, identityInput, button };
  }

  function decodeFirestoreValue(value) {
    if (!value || typeof value !== 'object') return '';
    if ('stringValue' in value) return value.stringValue;
    if ('integerValue' in value) return value.integerValue;
    if ('doubleValue' in value) return value.doubleValue;
    if ('booleanValue' in value) return value.booleanValue;
    if ('timestampValue' in value) return value.timestampValue;
    if ('nullValue' in value) return null;
    if ('mapValue' in value) return decodeFirestoreFields(value.mapValue && value.mapValue.fields);
    if ('arrayValue' in value) return (value.arrayValue && value.arrayValue.values || []).map(decodeFirestoreValue);
    return '';
  }

  function decodeFirestoreFields(fields) {
    return Object.fromEntries(Object.entries(fields || {}).map(([key, value]) => [key, decodeFirestoreValue(value)]));
  }

  async function makeInquiryKey(serviceCode, identityNumber, legacyDigitsOnly = false) {
    const savedServiceCode = String(serviceCode || '').trim();
    const savedIdentityNumber = String(identityNumber || '').trim();
    const source = legacyDigitsOnly
      ? `${normalizeDigits(savedServiceCode)}|${normalizeDigits(savedIdentityNumber)}`
      : `${savedServiceCode}|${savedIdentityNumber}`;
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(source));
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  async function readInquiryByKey(key) {
    const url = `${COLLECTION_URL}/${encodeURIComponent(key)}`;
    let response;
    let lastError;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        response = await fetch(url, {
          method: 'GET',
          headers: { Accept: 'application/json' },
          credentials: 'omit',
          cache: 'no-store',
        });
        if (response.status === 404) return null;
        if (response.ok) break;
        if (response.status >= 500 && attempt === 0) {
          await new Promise((resolve) => setTimeout(resolve, 350));
          continue;
        }
        throw new Error(`Firestore request failed: ${response.status}`);
      } catch (error) {
        lastError = error;
        if (attempt === 0) {
          await new Promise((resolve) => setTimeout(resolve, 350));
          continue;
        }
        throw lastError;
      }
    }
    if (!response || !response.ok) throw lastError || new Error('Firestore request failed');
    const document = await response.json();
    return decodeFirestoreFields(document.fields || {});
  }

  async function readInquiry(serviceCode, identityNumber) {
    const keys = [
      await makeInquiryKey(serviceCode, identityNumber),
      await makeInquiryKey(serviceCode, identityNumber, true),
    ].filter((key, index, all) => all.indexOf(key) === index);
    for (const key of keys) {
      const record = await readInquiryByKey(key);
      if (record) return record;
    }
    return null;
  }

  function escapeHtml(value) {
    return String(value === undefined || value === null || value === '' ? '-' : value)
      .replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[character]));
  }

  function setMessage(message, controls) {
    let node = document.getElementById('previewInquiryMessage');
    if (!node) {
      node = document.createElement('div');
      node.id = 'previewInquiryMessage';
      node.className = 'alert alert-danger text-center';
      node.setAttribute('role', 'alert');
      node.style.margin = '14px 0';
      node.style.direction = 'rtl';
      const host = controls.button.parentElement;
      host.insertBefore(node, controls.button);
    }
    node.textContent = message;
    node.hidden = false;
  }

  function clearMessage() {
    const node = document.getElementById('previewInquiryMessage');
    if (node) node.remove();
  }

  function ensureSpinnerStyle() {
    if (document.getElementById('previewInquirySpinnerStyle')) return;
    const style = document.createElement('style');
    style.id = 'previewInquirySpinnerStyle';
    style.textContent = '.preview-inquiry-spinner{display:inline-block;width:14px;height:14px;margin-left:7px;vertical-align:-2px;border:2px solid currentColor;border-left-color:transparent;border-radius:50%;animation:previewInquirySpin .7s linear infinite}@keyframes previewInquirySpin{to{transform:rotate(360deg)}}';
    document.head.appendChild(style);
  }

  function setLoading(controls, loading) {
    ensureSpinnerStyle();
    controls.button.disabled = loading;
    if (loading) {
      controls.button.dataset.previewOriginalText = controls.button.textContent.trim() || 'استعلام';
      controls.button.innerHTML = '<span class="preview-inquiry-spinner" aria-hidden="true"></span><span>جارٍ الاستعلام...</span>';
    } else {
      controls.button.textContent = controls.button.dataset.previewOriginalText || 'استعلام';
      delete controls.button.dataset.previewOriginalText;
    }
  }

  function fieldRow(label, value) {
    return `<div class="col-md-6"><span class="information-label">${label}:</span><div class="information-data">${escapeHtml(value)}</div></div>`;
  }

  function firstExistingField(record, keys) {
    const source = record && typeof record === 'object' ? record : {};
    const key = keys.find((candidate) => Object.prototype.hasOwnProperty.call(source, candidate));
    return key ? { present: true, value: source[key] } : { present: false, value: undefined };
  }

  function sourceRecord(record) {
    if (record && Array.isArray(record.data)) return record.data[0] || {};
    return record && typeof record === 'object' ? record : {};
  }

  function ensureResultStyles() {
    if (document.getElementById('previewInquiryResultStyles')) return;
    const style = document.createElement('style');
    style.id = 'previewInquiryResultStyles';
    style.textContent = '.results-inquiery{background:#f7f7f7 !important;padding:10px !important;margin:25px 1px 1px !important;border:1px solid gainsboro !important;text-align:center !important}.results-inquiery>div{padding:10px !important}.results-inquiery span{display:block;font-weight:700;padding:8px 0}.results-inquiery .information-data{display:block !important;font-weight:400 !important;padding:0 !important;margin:0 !important;text-align:center !important}';
    document.head.appendChild(style);
  }

  function showResult(record, controls) {
    ensureResultStyles();
    const source = sourceRecord(record);
    const companionName = firstExistingField(source, ['Patient Name', 'companionName', 'companion', 'patientCompanionName']);
    const companionRelation = firstExistingField(source, ['Relationship', 'companionRelation', 'relation', 'kinship', 'patientCompanionRelation']);
    const name = firstExistingField(source, ['PatientName', 'name']);
    const issueDate = firstExistingField(source, ['SickLeaveDate', 'issueDate']);
    const admissionDate = firstExistingField(source, ['From', 'admissionDate']);
    const dischargeDate = firstExistingField(source, ['To', 'dischargeDate']);
    const duration = firstExistingField(source, ['Duration', 'leaveDuration']);
    const doctorName = firstExistingField(source, ['Doctor NAME', 'DoctorName', 'doctorName']);
    const jobTitle = firstExistingField(source, ['JobTitle', 'jobTitle']);
    const rows = [
      fieldRow('الاسم', name.value),
      fieldRow('تاريخ إصدار التقرير', issueDate.value),
      fieldRow('تبدأ من', admissionDate.value),
      fieldRow('وحتى', dischargeDate.value),
      fieldRow('المدة بالأيام', duration.value),
      fieldRow('اسم الطبيب', doctorName.value),
      fieldRow('المسمى الوظيفي', jobTitle.value),
    ];
    if (companionRelation.present) rows.splice(1, 0, fieldRow('صلة القرابة', companionRelation.value));
    if (companionName.present) rows.splice(1, 0, fieldRow('اسم المرافق', companionName.value));

    let panel = document.getElementById('previewInquiryResults');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'previewInquiryResults';
      panel.className = 'results-inquiery row';
      panel.setAttribute('aria-live', 'polite');
      const formHost = controls && controls.button.parentElement;
      if (formHost && controls.button) formHost.insertBefore(panel, controls.button);
      else document.querySelector('.inquiries-container')?.appendChild(panel);
    }
    panel.innerHTML = rows.join('');
    panel.hidden = false;
  }

  function clearResult() {
    const panel = document.getElementById('previewInquiryResults');
    if (panel) panel.remove();
  }

  function resetSearch(controls) {
    clearMessage();
    clearResult();
    controls.serviceInput.value = '';
    controls.identityInput.value = '';
    controls.button.type = 'submit';
    controls.button.textContent = 'استعلام';
    controls.button.disabled = false;
    delete controls.button.dataset.previewMode;
  }

  async function handleQuery(event, controls) {
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();

    if (controls.button.dataset.previewMode === 'result') {
      resetSearch(controls);
      return;
    }

    clearMessage();
    clearResult();
    const serviceCode = String(controls.serviceInput.value || '').trim();
    const identityRaw = String(controls.identityInput.value || '').trim();
    const identity = normalizeDigits(identityRaw);

    if (!serviceCode || !identityRaw) {
      setMessage('لا يوجد نتائج', controls);
      return;
    }
    const identityHasInvalidFormat = identity.length !== 10 || /[^0-9٠-٩]/.test(identityRaw) || !/^[12]/.test(identity) || /^([0-9])\1{9}$/.test(identity);
    if (identityHasInvalidFormat) {
      setMessage('رقم الهوية خاطئ', controls);
      return;
    }

    setLoading(controls, true);
    try {
      const record = await readInquiry(serviceCode, identity);
      if (!record || record.status !== 'active') {
        setMessage('لا يوجد نتائج', controls);
        return;
      }
      showResult(record, controls);
      controls.button.disabled = false;
      controls.button.type = 'button';
      controls.button.textContent = 'استعلام جديد';
      controls.button.dataset.previewMode = 'result';
    } catch (error) {
      console.error('preview_inquiry_firestore_error', error);
      setMessage('خطأ في الاستعلام', controls);
    } finally {
      if (controls.button.dataset.previewMode !== 'result') setLoading(controls, false);
    }
  }

  function attach() {
    if (attached) return;
    document.addEventListener('click', (event) => {
      const target = event.target instanceof Element ? event.target.closest('button') : null;
      if (!target) return;
      const text = String(target.textContent || '').replace(/\s+/g, ' ').trim();
      if (text !== 'استعلام' && text !== 'استعلام جديد') return;
      const controls = findControls();
      if (!controls || controls.button !== target) return;
      handleQuery(event, controls);
    }, true);
    attached = true;
    window.__SEHA_INQUIRY_FIRESTORE_PREVIEW__ = true;
  }

  window.addEventListener('DOMContentLoaded', attach);
  window.addEventListener('load', attach);
  attach();
})();
